import React from 'react';

import { useAuth } from '../../hooks/auth';

import logoImg from '../../assets/logo.svg';

import {
  Container,
  Side,
  Logo,
  Nav,
  NavLink,
  ActionBar,
  Action,
  ActionHighlighted,
  UserHighlighted,
} from './styles';

const Header = () => {
  const { user } = useAuth();

  return (
    <Container>
      <Side>
        <Logo to="/">
          <img src={logoImg} alt="Aircnc" />
        </Logo>
      </Side>

      <Nav>
        <NavLink to="/">Home</NavLink>

        {!!user && (
          <>
            <NavLink to="/spots" selected>Spots</NavLink>
            <NavLink to="/spots/new">Create Spot</NavLink>
          </>
        )}
      </Nav>

      <ActionBar>
        {!user ? (
          <>
            <Action to="/signin">Login</Action>
            <ActionHighlighted to="/signup">Sign Up</ActionHighlighted>
          </>
        ) : (
          <>
            <UserHighlighted>
              <div>{user.name.split('')[0]}</div>
              Sair
            </UserHighlighted>
          </>
        )}
      </ActionBar>
    </Container>
  );
};

export default Header;
