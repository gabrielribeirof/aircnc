import styled from 'styled-components';

export const Wrapper = styled.main`
  max-width: 1220px;
  margin: 0 auto;
  padding: 0 20px;
`;
