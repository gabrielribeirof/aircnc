import styled from 'styled-components';

export const Container = styled.div`
  max-width: 420px;
  margin: 0 auto;
  margin-top: 100px;
`;
