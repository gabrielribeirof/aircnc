import React, { useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';

import api from '../../services/api';

import Button from '../../components/Button';

import {
  Container,
  Thumbnail,
  Info,
  Head,
  Row,
  Tags,
  Description,
  Actions,
} from './styles';

const Spot = () => {
  const [spot, setSpot] = useState([]);

  const history = useHistory();
  const { spot_id } = useParams();

  useEffect(() => {
    api.get(`spots/${spot_id}`).then((response) => {
      setSpot(response.data);
    });
  }, [spot_id]);

  return (
    <Container>
      <Thumbnail>
        <img src={spot.thumbnail_url} alt="Thumbnail" />
      </Thumbnail>

      <Info>
        <Head>
          <Row>
            <div>
              <h1 className="title">{spot.name}</h1>
              <span className="place">São Paulo, Brazil</span>
            </div>

            <span className="price">
              $
              {spot.price}
              /dia
            </span>
          </Row>

          <Tags>
            <div>Resort</div>
            <div>Adventure</div>
            <div>Hotel</div>
          </Tags>
        </Head>

        <Description>
          <h2>Description</h2>

          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent et dolor
            bibendum diam ullamcorper bibendum vitae a ex. Ut in ipsum lacus. Nullam
            dictum nisi sem, sed sagittis arcu ultricies ut. Mauris sodales nisl
            velit. Mauris quis velit at urna bibendum viverra.
          </p>
        </Description>

        <Actions>
          <Button onClick={() => history.push(`/book/${spot_id}`)}>Book Now</Button>
        </Actions>
      </Info>
    </Container>
  );
};

export default Spot;
