import React, { useState, useEffect, useCallback } from 'react';
import { useHistory } from 'react-router-dom';
import { useAuth } from '../../hooks/auth';

import api from '../../services/api';

import Card from '../../components/Card';
import Button from '../../components/Button';

import { WelcomeBanner, SpotRequests, SpotList } from './styles';

const Spots = () => {
  const [spots, setSpots] = useState([]);
  const [requests, setRequests] = useState([]);

  const { user } = useAuth();
  const history = useHistory();

  useEffect(() => {
    api.get('bookings', {
      params: {
        status: 'pending',
      },
    }).then((response) => {
      setRequests(response.data);
    });

    api.get('spots').then((response) => {
      setSpots(response.data);
    });
  }, []);

  const handleAccept = useCallback(async (id) => {
    await api.post(`bookings/${id}/approve`);

    setRequests(requests.filter((request) => request._id !== id));
  }, [requests]);

  const handleReject = useCallback(async (id) => {
    await api.post(`bookings/${id}/reject`);

    setRequests(requests.filter((request) => request._id !== id));
  }, [requests]);

  return (
    <Card>
      <WelcomeBanner>
        Seja bem-vindo(a)
        {' '}
        {user.name}
      </WelcomeBanner>

      <SpotRequests>
        {requests.map((request) => {
          const date = new Date(request.date);

          const formattedDate = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;

          return (
            <div key={request._id}>
              <span>
                <b>{request.user.email}</b>
                {' '}
                está solicitando uma reserva em
                {' '}
                <b>{request.spot.name}</b>
                {' '}
                para a data:
                {' '}
                <b>{formattedDate}</b>
                .
              </span>

              <button
                type="button"
                className="accept"
                onClick={() => handleAccept(request._id)}
              >
                ACEITAR
              </button>

              <button
                type="button"
                className="reject"
                onClick={() => handleReject(request._id)}
              >
                REJEITAR
              </button>
            </div>
          );
        })}
      </SpotRequests>

      <SpotList>
        {spots.map((spot) => (
          <div key={spots._id} className="spot-item">
            <header style={{ backgroundImage: `url(${spot.thumbnail_url})` }} />

            <strong>{spot.name}</strong>
            <span>{spot.price ? `R$${spot.price}/dia` : 'GRATUITO'}</span>

            <button
              type="button"
              disabled={spot.user._id === user._id}
              onClick={() => history.push(`/spots/${spot._id}/book`)}
            >
              {spot.user._id === user._id ? 'Seu ponto' : 'Solicitar reserva'}
            </button>
          </div>
        ))}
      </SpotList>

      <Button onClick={() => history.push('/spots/new')}>
        CADASTRAR NOVO PONTO
      </Button>
    </Card>
  );
};

export default Spots;
